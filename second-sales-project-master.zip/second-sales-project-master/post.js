
var promise = require('bluebird');
var bodyParser = require('body-parser')
var options = { promiseLib: promise }
var pgp = require('pg-promise')(options);
var express = require('express');
var app = new express();
var fs = require('fs');
var path = require('path');

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var cs = 'postgres://postgres:system@localhost:5432/secondsales';
var db = pgp(cs);


app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});
  
app.get('/displayall', (req, res, next) => {

    db.any('select * from post').then(function (data) {
        res.send(data);
    })
})


app.get('/display/:id', (req, res, next) => {
    var i = req.params.id;
    console.log(i);
    db.any('select * from post where id=$1', i).then(function (data) {
        res.send(data);
    })
})
app.get('/register', (req, res, next) => {

    db.any('select * from registration').then(function (data) {
        res.send(data);
    })
})


app.get('/search/category/:catg', (req, res, next) => {
    var i = req.params.catg;
    db.any('select * from post where a_types=$1', i).then(function (data) {
        console.log(data);
        res.send(data);
    })
})





app.get('/login/:un/:pwd', (req, res, next) => {
    var n = req.params.un;
    var p = req.params.pwd;
    db.any('select * from registration  where u_email =$1 and u_password =$2', [n, p]).then(function (data) {
        console.log(data);
        res.send(data);
    })
});



app.get('/login/:id', (req, res, next) => {
    var i = req.params.id;
    db.any('select * from registration where u_email=$1', i).then(function (data) {
        res.send(data);
    })
})


app.post('/register', (req, res, next) => {
    var n = req.body.u_name;
    var p = req.body.u_password;
    var e = req.body.u_email;
    var cn = req.body.contactno;
    db.none('insert into registration values($1,$2,$3,$4)', [n, p, e, cn]).then(function () {
        console.log('Record Inserted ...')
        res.status(200).send({ message: "Inserted Success.." })
    })
})
app.post('/post', (req, res, next) => {
    var e = req.body.a_email;
    var t = req.body.a_title;
    var ty = req.body.a_types;
    var d = req.body.a_description;
    var ci = req.body.a_city;
    var ca = req.body.a_category;
    var data = req.body.pimage;
    var pr = req.body.a_price;  
    var nu = req.body.contactno;


    var pt = '';
    var dt = new Date();
    ptr = dt.getFullYear() + "" + dt.getMonth() + "" + dt.getMilliseconds() + '.png';
    pts = './public/' + ptr;
    fs.writeFile(pts, data, 'base64', (err) => {
        if (err)
            console.log(err)
        else {
            console.log('Image Saved Success...');
        }
    });
    ptr = 'http://localhost:4555/' + ptr;
    db.none('insert into post values($1,$2,$3,$4,$5,$6,$7,$8,$9)', [e, t, ty, d, ci, ca, ptr, pr, nu,]).then(function () {
        console.log('Record Inserted ...')
        res.status(200).send({ message: "Inserted Success.." });
    })
})




app.delete('/login/:id', (req, res, next) => {
    var i = req.params.id;

    db.result('delete from registration where  u_email=$1', i).then(function (data) {
        res.status(200).send({ message: "Deleted Success.." })
    })
})

app.delete('/post/:a_email', (req, res, next) => {
    var i = req.params.a_email;
    db.result('delete from post where a_email=$1', i).then(function (data) {
        res.status(200).send({ message: "Deleted Success.." })
    })
})

app.put('/login/:id', (req, res, next) => {
    var i = req.params.id;
    var u = req.body.u_name;
    var p = req.body.u_password;
    var c = req.body.u_confirm;
    var e = req.body.u_email;
    var co = req.body.contactno

    db.none('update registration set u_name=$1,u_password=$2,u_confirm=$3,contactno=$4 where u_email=$5', [u, p, c, co, e, i]).then(function () {
        console.log('Record Updated Success ...')
        res.status(200).send({ message: "Updated Succes.." })
    })
})
app.put('/post/:id', (req, res, next) => {
    var i = parseInt(req.params.id);
    var t = req.body.a_title;
    var ty = req.body.a_types;
    var ca = req.body.a_category;
    var de = req.body.a_description;
    var p = req.body.a_price;
    var c = req.body.a_city;
    var e = req.body.a_email;

    db.none('update post set a_email=$1, a_title=$2,a_types=$3,a_price=$4,a_description=$5,a_city=$6,a_category=$7 where id=$8', [e, t, ty, p, de, c, ca, i]).then(function () {
        console.log('Record Updated Success ...')
        res.status(200).send({ message: "Updated Succes.." })
    })
})

app.listen(4555, (err) => {
    if (err)
        console.log('Server Cant Start ...Erorr....');
    else
        console.log('Server Started at : http://localhost:4555')
})