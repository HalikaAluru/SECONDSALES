import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Register } from '../models/login';
import { LogserviceService } from '../services/logservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private frmGrp: FormGroup;
  private frmBdr: FormBuilder;
  private u_email: String = '';
  private u_password: String = '';
  private msg: String = '';
  private msg1: String = '';

  constructor(private serv: LogserviceService, private route: Router) {
    this.frmBdr = new FormBuilder;
  }



  Login() {

    const un = this.frmGrp.controls['u_email'].value;
    const pwd = this.frmGrp.controls['u_password'].value;
    this.serv.CheckLogin(un, pwd).subscribe(data => {
      if (data.length > 0) {

        localStorage.setItem('u_email', un);

        this.route.navigate(['/displayall']);
      } else {
        alert('Invalid Login !.. Please Register to Login');
      }
    });

  }

  ngOnInit() {
    this.frmGrp = this.frmBdr.group({
      u_email: [''],
      u_password: ['']
    });
    this.u_email = localStorage.getItem('u_email');
  }
}
