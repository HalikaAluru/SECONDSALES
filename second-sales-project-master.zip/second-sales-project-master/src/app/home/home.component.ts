import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LogserviceService } from '../services/logservice.service';
import { Post, Register } from '../models/login';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

private result:any[]=[];
  private router: Router
  navigate(){
this.router.navigate(['/displayall/'])}

  constructor() {
  }
  ngOnInit() {
   
  }

 
}
