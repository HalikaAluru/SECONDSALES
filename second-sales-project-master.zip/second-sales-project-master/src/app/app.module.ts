import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { DisplayallComponent } from './displayall/displayall.component';
import { DisplayComponent } from './display/display.component';
import { PostadComponent } from './postad/postad.component';
import { RegisterComponent } from './register/register.component';
import { ReactiveFormsModule, FormGroup, FormControl, } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LogserviceService } from './services/logservice.service';
import { Angular2FontawesomeModule } from 'angular2-fontawesome/angular2-fontawesome';
import { SearchComponent } from './search/search.component';


const myRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'post', component: PostadComponent },
  { path: 'home', component: HomeComponent },
  { path: 'displayall', component: DisplayallComponent },
  { path: 'display/:id', component: DisplayComponent },
  { path: 'search', component: SearchComponent },
   { path: '**', redirectTo: '/home', pathMatch: 'full' },
  ];


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    DisplayallComponent,
    DisplayComponent,
    PostadComponent,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    SearchComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    Angular2FontawesomeModule,
    RouterModule.forRoot(myRoutes)
  ],
  providers: [LogserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
