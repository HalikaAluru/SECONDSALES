import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LogserviceService } from '../services/logservice.service';
import { Post, Register } from '../models/login';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';



@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})


export class DisplayallComponent implements OnInit {
  private PostAd: any[];
  private id: any;
  private frmGrp: FormGroup;
  private fb: FormBuilder;
  private p: Post;
  private result;
  constructor(private postService: LogserviceService, private acr: ActivatedRoute, private router: Router) {
    this.fb = new FormBuilder();
    this.p = new Post();
  }
  btnDetails(n: number) {
    this.router.navigate(['/display/' + n]);
  }
  btnDelete(n: String) {

    this.postService.Deletepost(n).subscribe(data => console.log(data));
    location.reload();
  }
  ngOnInit() {
    this.postService.GetAllPost().subscribe((data) => { this.PostAd = data; });
    // this.serv.GetMobileDetails(this.i).subscribe((data)=>{this.proList=data;});
    const id = this.acr.snapshot.params.id;
    this.postService.GetAllPostById(id)
      .subscribe(data => { this.id = data; console.log(data); });
  }
}


