  import { Component, OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { Post } from '../models/login';
  import { LogserviceService } from '../services/logservice.service';
  @Component({
    selector: 'app-postad',
    templateUrl: './postad.component.html',
    styleUrls: ['./postad.component.css']
  })


  export class PostadComponent implements OnInit {

    private url: '';
    private frmGrp1: FormGroup;
    private fb: FormBuilder;
    private pos: Post;

    constructor(private posServ: LogserviceService) {
      this.fb = new FormBuilder();
      this.pos = new Post();

    }
    onSelectFile(event) {
      if (event.target.files && event.target.files[0]) {
        const reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]); // read file as data url
        reader.onload = (ev: any) => { // called once readAsDataURL is completed
          this.url = ev.target.result;
          this.pos.pimage = reader.result;
        };
      }
    }
    btnSubmit() {
      this.pos.a_email = this.frmGrp1.controls['a_email'].value;
      this.pos.a_title = this.frmGrp1.controls['a_title'].value;
      this.pos.a_types = this.frmGrp1.controls['a_types'].value;
      this.pos.a_description = this.frmGrp1.controls['a_description'].value;
      this.pos.a_city = this.frmGrp1.controls['a_city'].value;
      this.pos.a_category = this.frmGrp1.controls['a_category'].value;
      this.pos.pimage = this.pos.pimage.replace('data:image/jpeg;base64,', '');
      this.pos.pimage = this.pos.pimage.replace('data:image/gif;base64,', '');
      this.pos.contactno = this.frmGrp1.controls['contactno'].value;
      this.pos.a_price = this.frmGrp1.controls['a_price'].value;
      this.posServ.Post(this.pos).subscribe(data => console.log(data));
    }
    onSubmit() {
      if (this.frmGrp1.valid) {
        alert('Form Submitted!');
        this.frmGrp1.reset(); } else {
          alert('please Register First');
        }
      }


    ngOnInit() {
      this.frmGrp1 = this.fb.group({
        a_email: ['', Validators.required],
        a_title: ['', Validators.required],
        a_types: ['', Validators.required],
        a_description: ['', Validators.required],
        a_city: ['', Validators.required],
        a_category: ['', Validators.required],
        pimage: ['', Validators.required],
        contactno: ['', Validators.required],
        a_price: ['', Validators.required],

      });
    }
  }
