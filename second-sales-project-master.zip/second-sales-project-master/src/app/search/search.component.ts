import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { LogserviceService } from '../services/logservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  private frmGrp: FormGroup;
  private fb: FormBuilder;
  private post: any[] = [];
  constructor(private logSer: LogserviceService, private router: Router) {
    this.fb = new FormBuilder();
  }
  btnSearch() {
    const s = this.frmGrp.controls['ddlSearchBy'].value;
    const n = this.frmGrp.controls['txtSearch'].value;
    if (s === 'Select Category') {
      this.logSer.GetCategory(n).subscribe(data => {console.log(data); this.post = data; });
      console.log(this.post);
    }
  }
  btnDetails(n: number) {
    /*this.postService.GetAllPostById(n).subscribe((data) => { this.result = data; });*/

    this.router.navigate(['/display/' + n]);
  }


  ngOnInit() {
    this.frmGrp = this.fb.group({
      ddlSearchBy: [''],
      txtSearch: ['']
    });
  }

}


