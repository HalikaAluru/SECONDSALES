import { Injectable } from '@angular/core';
import { Post, Register } from '../models/login';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { mapChildrenIntoArray } from '@angular/router/src/url_tree';

@Injectable({
  providedIn: 'root'
})
export class LogserviceService {

  constructor(private http: HttpClient) {

  }


  GetVehciles(): Observable<any> {
    return this.http.get('http://localhost:4555/vehicles', { responseType: 'json' });
  }
  GetAllPost(): Observable<any> {
    return this.http.get('http://localhost:4555/displayall', { responseType: 'json' });
  }

  GetAllPostById(n: number): Observable<any> {
    return this.http.get('http://localhost:4555/display/' + n, { responseType: 'json' });
  }

  GetCategory(t: string): Observable<any> {
    return this.http.get('http://localhost:4555/search/category/' + t, { responseType: 'json' });
  }



  Post(pos: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };
    console.log(pos);
    return this.http.post('http://localhost:4555/post', JSON.stringify(pos), httpOptions);
  }

  Register(reg: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };
    console.log(reg);
    return this.http.post('http://localhost:4555/register', JSON.stringify(reg), httpOptions);
  }
  CheckLogin(un: string, pwd: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-Type': 'application/json' })
    };

    return this.http.get('http://localhost:4555/login/' + un + '/' + pwd, { responseType: 'json' });

  }
  Deletepost(n: String): Observable<any> {
    console.log(n);
    return this.http.delete('http://localhost:4555/post/' + n, { responseType: 'json' });
  }
}

