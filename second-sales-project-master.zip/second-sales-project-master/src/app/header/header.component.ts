import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
 
  logOut() {


    localStorage.removeItem('u_email');
    this.router.navigate([''])
    location.reload()


  }

  constructor(private router: Router) { }

  ngOnInit() {
  }

}
