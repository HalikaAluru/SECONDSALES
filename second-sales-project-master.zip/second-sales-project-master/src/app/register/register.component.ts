import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, RequiredValidator } from '@angular/forms';
import { Post, Register } from '../models/login';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { LogserviceService } from '../services/logservice.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  private reg: Register;
  private angForm: FormGroup;
  private fb: FormBuilder;

  constructor(private regi: LogserviceService) {
  this.fb = new FormBuilder();
 }

  btnRegister() {
    this.reg = new Register();
    this.reg.u_name  = this.angForm.controls['u_name'].value;
    this.reg.u_password = this.angForm.controls['u_password'].value;
    this.reg.u_email = this.angForm.controls['u_email'].value;
    this.reg.contactno = this.angForm.controls['contactno'].value;
    this.regi.Register(this.reg).subscribe(data => console.log(data));
  }

  onSubmit() {
    if (this.angForm.valid) {
      alert('Form Submitted!');
      this.angForm.reset();
    }
  }




 ngOnInit() {
   this.angForm = this.fb.group({
      u_name: ['', Validators.required],
      u_password: ['', Validators.required],
      u_confirm: ['', Validators.required],
     u_email: ['', Validators.required],
      contactno: ['', Validators.required],
    });
  }
}







