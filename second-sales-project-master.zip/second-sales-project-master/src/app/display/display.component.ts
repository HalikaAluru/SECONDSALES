import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LogserviceService } from '../services/logservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { identifierModuleUrl } from '@angular/compiler';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  private Post: any[] = [];
  constructor(private acr: ActivatedRoute, private serv: LogserviceService ) {

  }
  getData() {
  }

  ngOnInit() {
    const id = this.acr.snapshot.params.id;
    this.serv.GetAllPostById(id).subscribe((data) => { this.Post = data; });
    console.log(this.Post);
  }

}
