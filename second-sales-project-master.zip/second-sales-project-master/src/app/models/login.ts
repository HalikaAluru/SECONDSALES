
export class Post {
    a_email: string;
    a_title: string;
    a_types: string;
    a_price: string;
    a_description: string;
    a_city: string;
    a_category: string;
    pimage: any;
    contactno: string;
}

export class Register {
    u_name: string;
    u_password: string;
    u_email: string;
    contactno: number;
}

